from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich import box

from graph.builder import build_graph
from memory.memory import save_message

console = Console()


def banner():
    console.clear()
    console.print(
        Panel.fit(
            "[bold cyan]ABC TECHNOLOGIES[/bold cyan]\n"
            "[bold white]AI CUSTOMER SUPPORT ASSISTANT[/bold white]",
            border_style="cyan",
            box=box.DOUBLE,
        )
    )


def get_customer():
    return Prompt.ask(
        "[bold green]Customer ID[/bold green]",
        default="CUST001",
    )


def show_response(response):
    console.print()
    console.print(
        Panel(
            response,
            title="[bold green]Support Response[/bold green]",
            border_style="green",
            box=box.ROUNDED,
        )
    )


def main():

    graph = build_graph()

    banner()

    customer = get_customer()

    console.print(Rule("[bold blue]Start Chat[/bold blue]"))

    while True:

        query = Prompt.ask("\n[bold cyan]You[/bold cyan]")

        if query.lower() in ("exit", "quit"):
            break

        state = {

            "customer_id": customer,

            "query": query,

        }

        with console.status(
            "[bold cyan]Processing your request...[/bold cyan]",
            spinner="dots",
        ):

            result = graph.invoke(state)

        response = result.get("response", "")

        if response:

            show_response(response)

            save_message(
                customer,
                "user",
                query,
            )

            save_message(
                customer,
                "assistant",
                response,
            )

        else:

            console.print(
                "[bold red]No response generated.[/bold red]"
            )

        console.print(Rule(style="grey50"))

    console.print(
        "\n[bold green]Thank you for using ABC Technologies Support![/bold green]"
    )


if __name__ == "__main__":
    main()