from langgraph.graph import StateGraph
from langgraph.graph import END

from graph.state import SupportState
from graph.routes import (
    route_by_intent,
    route_after_agent,
    route_after_hitl,
)

from agents.classifier import classify_intent

from agents.sales import sales_agent
from agents.technical import technical_agent
from agents.billing import billing_agent
from agents.account import account_agent

from agents.human import human_approval
from agents.supervisor import supervisor_agent

from rag.rag_node import rag_node

from memory.memory import memory_node


def end_rejected(state: SupportState):

    return state


def build_graph():

    graph = StateGraph(SupportState)

    graph.add_node("classifier", classify_intent)

    graph.add_node("rag", rag_node)

    graph.add_node("sales_agent", sales_agent)

    graph.add_node("technical_agent", technical_agent)

    graph.add_node("billing_agent", billing_agent)

    graph.add_node("account_agent", account_agent)

    graph.add_node("memory_recall", memory_node)

    graph.add_node("human_approval", human_approval)

    graph.add_node("supervisor", supervisor_agent)

    graph.add_node("end_rejected", end_rejected)

    graph.set_entry_point("classifier")

    graph.add_conditional_edges(

        "classifier",

        route_by_intent,

        {

            "sales_agent": "rag",

            "technical_agent": "rag",

            "billing_agent": "rag",

            "account_agent": "rag",

            "memory_recall": "memory_recall",

        },

    )

    graph.add_conditional_edges(

        "rag",

        route_by_intent,

        {

            "sales_agent": "sales_agent",

            "technical_agent": "technical_agent",

            "billing_agent": "billing_agent",

            "account_agent": "account_agent",

        },

    )

    for node in [

        "sales_agent",

        "technical_agent",

        "billing_agent",

        "account_agent",

    ]:

        graph.add_conditional_edges(

            node,

            route_after_agent,

            {

                "human_approval": "human_approval",

                "supervisor": "supervisor",

            },

        )

    graph.add_edge(

        "memory_recall",

        "supervisor",

    )

    graph.add_conditional_edges(

        "human_approval",

        route_after_hitl,

        {

            "supervisor": "supervisor",

            "end_rejected": "end_rejected",

        },

    )

    graph.add_edge(

        "supervisor",

        END,

    )

    graph.add_edge(

        "end_rejected",

        END,

    )

    return graph.compile()