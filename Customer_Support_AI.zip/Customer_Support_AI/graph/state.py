from typing import List, Optional

from typing_extensions import TypedDict


class SupportState(TypedDict, total=False):

    # Customer

    customer_id: str

    query: str

    # Intent

    intent: str

    requires_hitl: bool

    # RAG

    context: str

    # Final response

    response: str

    # Human Approval

    hitl_approved: bool

    hitl_comment: str

    # Memory

    chat_history: List[dict]