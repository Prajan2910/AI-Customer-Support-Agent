from graph.state import SupportState


def route_by_intent(state: SupportState):

    intent = state.get("intent", "").lower()

    routes = {

        "sales": "sales_agent",

        "technical": "technical_agent",

        "billing": "billing_agent",

        "account": "account_agent",

        "memory": "memory_recall",

    }

    return routes.get(intent, "sales_agent")


def route_after_agent(state: SupportState):

    if state.get("requires_hitl"):

        return "human_approval"

    return "supervisor"


def route_after_hitl(state: SupportState):

    if state.get("hitl_approved"):

        return "supervisor"

    return "end_rejected"