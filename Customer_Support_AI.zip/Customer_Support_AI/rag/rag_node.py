from graph.state import SupportState

from rag.retriever import retrieve_context


def rag_node(
    state: SupportState,
):

    context = retrieve_context(
        state["query"]
    )

    return {

        **state,

        "context": context,

    }