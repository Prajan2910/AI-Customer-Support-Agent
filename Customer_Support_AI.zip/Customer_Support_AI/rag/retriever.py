import os

from langchain_community.vectorstores import FAISS
from langchain_ollama import OllamaEmbeddings

from rag.loader import load_documents

from config import (
    FAISS_DIR,
    EMBED_MODEL,
    TOP_K,
)

_vectorstore = None


def embeddings():

    return OllamaEmbeddings(
        model=EMBED_MODEL
    )


def vectorstore():

    global _vectorstore

    if _vectorstore is not None:
        return _vectorstore

    emb = embeddings()

    if os.path.exists(FAISS_DIR):

        try:

            _vectorstore = FAISS.load_local(
                FAISS_DIR,
                emb,
                allow_dangerous_deserialization=True,
            )

            return _vectorstore

        except Exception:

            pass

    docs = load_documents()

    if not docs:
        raise RuntimeError(
            "No documents found inside data folder."
        )

    _vectorstore = FAISS.from_documents(
        docs,
        emb,
    )

    os.makedirs(
        FAISS_DIR,
        exist_ok=True,
    )

    _vectorstore.save_local(
        FAISS_DIR
    )

    return _vectorstore


def retrieve_context(
    query,
    k=TOP_K,
):

    docs = vectorstore().similarity_search(
        query,
        k=k,
    )

    if not docs:
        return ""

    context = []

    for doc in docs:
        context.append(doc.page_content)

    return "\n\n".join(context)