import sqlite3
import os

from graph.state import SupportState

DB_PATH = os.path.join(
    os.path.dirname(__file__),
    "memory.db",
)


def initialize_database():

    conn = sqlite3.connect(DB_PATH)

    cur = conn.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS conversations(

            id INTEGER PRIMARY KEY AUTOINCREMENT,

            customer_id TEXT,

            role TEXT,

            message TEXT

        )
        """
    )

    conn.commit()

    conn.close()


initialize_database()


def save_message(customer_id, role, message):

    conn = sqlite3.connect(DB_PATH)

    cur = conn.cursor()

    cur.execute(

        """
        INSERT INTO conversations
        (customer_id,role,message)
        VALUES(?,?,?)
        """,

        (

            customer_id,

            role,

            message,

        ),

    )

    conn.commit()

    conn.close()


def get_history(customer_id, limit=10):

    conn = sqlite3.connect(DB_PATH)

    cur = conn.cursor()

    cur.execute(

        """
        SELECT role,message
        FROM conversations

        WHERE customer_id=?

        ORDER BY id DESC

        LIMIT ?
        """,

        (

            customer_id,

            limit,

        ),

    )

    rows = cur.fetchall()

    conn.close()

    rows.reverse()

    history = []

    for role, message in rows:

        history.append(

            {

                "role": role,

                "content": message,

            }

        )

    return history


def memory_node(state: SupportState):

    history = get_history(

        state["customer_id"]

    )

    previous_user = None

    for item in reversed(history):

        if item["role"] == "user":

            previous_user = item["content"]

            break

    if previous_user is None:

        response = "I couldn't find any previous support request."

    else:

        response = f"Your previous support issue was:\n\n{previous_user}"

    return {

        **state,

        "chat_history": history,

        "response": response,

    }