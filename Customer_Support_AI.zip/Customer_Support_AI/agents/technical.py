from langchain_ollama import ChatOllama

from graph.state import SupportState

from config import OLLAMA_MODEL, OLLAMA_BASE_URL

llm = ChatOllama(
    model=OLLAMA_MODEL,
    base_url=OLLAMA_BASE_URL,
    temperature=0.2,
)

PROMPT = """
You are a Technical Support Engineer.

Knowledge Base

{context}

Customer Question

{query}

Provide step-by-step troubleshooting.
"""


def technical_agent(state: SupportState):

    response = llm.invoke(

        PROMPT.format(

            context=state["context"],

            query=state["query"],

        )

    ).content

    return {

        **state,

        "response": response,

    }