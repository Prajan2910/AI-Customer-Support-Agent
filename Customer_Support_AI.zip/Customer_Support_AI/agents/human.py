from rich.console import Console
from rich.panel import Panel

from graph.state import SupportState

console = Console()


def human_approval(state: SupportState):

    console.print()

    console.print(
        Panel(
            f"""[bold yellow]Customer ID:[/bold yellow] {state["customer_id"]}

[bold cyan]Department:[/bold cyan] {state["intent"].title()}

[bold white]Customer Query:[/bold white]

{state["query"]}

----------------------------------------

[bold green]Draft Response[/bold green]

{state["response"]}
""",
            title="Human Approval Required",
            border_style="yellow",
        )
    )

    while True:

        console.print()

        choice = input(
            "Approve request? (A = Approve / R = Reject): "
        ).strip().lower()

        if choice in ["a", "approve"]:

            comment = input(
                "Supervisor comment (optional): "
            ).strip()

            return {

                **state,

                "hitl_approved": True,

                "hitl_comment": comment,

            }

        elif choice in ["r", "reject"]:

            reason = input(
                "Reason for rejection: "
            ).strip()

            return {

                **state,

                "hitl_approved": False,

                "response":
                    "Your request has not been approved by the supervisor. "
                    + reason,

            }

        else:

            print()

            print("Please type A or R.")