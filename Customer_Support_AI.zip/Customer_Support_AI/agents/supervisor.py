from langchain_ollama import ChatOllama

from graph.state import SupportState

from config import (
    OLLAMA_MODEL,
    OLLAMA_BASE_URL,
)

llm = ChatOllama(
    model=OLLAMA_MODEL,
    base_url=OLLAMA_BASE_URL,
    temperature=0.1,
)

PROMPT = """
You are the Customer Support Supervisor.

Improve the draft below.

Customer Query

{query}

Department

{intent}

Draft

{draft}

Human Approval

{approval}

Supervisor Comment

{comment}

Return ONLY the improved response.
"""


def supervisor_agent(state: SupportState):

    if state.get("hitl_approved") is False:

        return state

    approval = "Not Required"

    if state.get("hitl_approved"):

        approval = "Approved"

    response = llm.invoke(

        PROMPT.format(

            query=state["query"],

            intent=state["intent"],

            draft=state["response"],

            approval=approval,

            comment=state.get(
                "hitl_comment",
                "",
            ),

        )

    ).content

    return {

        **state,

        "response": response,

    }