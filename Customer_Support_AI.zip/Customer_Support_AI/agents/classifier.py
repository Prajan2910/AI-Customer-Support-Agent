from langchain_ollama import ChatOllama

from config import (
    OLLAMA_MODEL,
    OLLAMA_BASE_URL,
    HITL_KEYWORDS,
)

from graph.state import SupportState
from memory.memory import get_history

llm = ChatOllama(
    model=OLLAMA_MODEL,
    base_url=OLLAMA_BASE_URL,
    temperature=0,
)

PROMPT = """
You are an intent classifier.

Return ONLY one word.

sales
technical
billing
account
memory

Query:
{query}
"""


def classify_intent(state: SupportState):

    history = get_history(
        state["customer_id"]
    )

    query = state["query"].lower()

    if any(word in query for word in [

        "previous issue",

        "previous support",

        "last issue",

        "history",

        "what was my",

    ]):

        intent = "memory"

    elif any(word in query for word in [

        "refund",

        "invoice",

        "payment",

        "billing",

        "charge",

        "subscription",

        "cancel",

        "compensation",

    ]):

        intent = "billing"

    elif any(word in query for word in [

        "password",

        "profile",

        "account",

        "activate",

        "deactivate",

        "login",

    ]):

        intent = "account"

    elif any(word in query for word in [

        "error",

        "crash",

        "bug",

        "technical",

        "upload",

        "installation",

        "configuration",

    ]):

        intent = "technical"

    elif any(word in query for word in [

        "pricing",

        "price",

        "plan",

        "software",

        "product",

        "subscription plan",

    ]):

        intent = "sales"

    else:

        intent = llm.invoke(
            PROMPT.format(
                query=query
            )
        ).content.strip().lower()

    requires_hitl = any(

        word in query

        for word in HITL_KEYWORDS

    )

    return {

        **state,

        "intent": intent,

        "requires_hitl": requires_hitl,

        "chat_history": history,

    }