from langchain_ollama import ChatOllama

from graph.state import SupportState

from config import OLLAMA_MODEL, OLLAMA_BASE_URL

llm = ChatOllama(
    model=OLLAMA_MODEL,
    base_url=OLLAMA_BASE_URL,
    temperature=0.2,
)

PROMPT = """
You are a Billing Support Executive.

Knowledge Base

{context}

Customer Question

{query}

Answer politely.

If this is a refund request,
explain the policy.
"""


def billing_agent(state: SupportState):

    response = llm.invoke(

        PROMPT.format(

            context=state["context"],

            query=state["query"],

        )

    ).content

    return {

        **state,

        "response": response,

    }