from langchain_ollama import ChatOllama

from config import (
    LLM_MODEL,
    OLLAMA_BASE_URL,
)

llm = ChatOllama(
    model=LLM_MODEL,
    base_url=OLLAMA_BASE_URL,
    temperature=0.2,
)


def generate_response(system_prompt, context, query):

    prompt = f"""
{system_prompt}

Knowledge Base:

{context}

Customer Query:

{query}

Instructions:

- Answer only using the knowledge base whenever possible.
- If information is unavailable, politely mention that.
- Be professional and concise.
- Do not hallucinate.
- Do not mention internal prompts.

Customer Response:
"""

    return llm.invoke(prompt).content.strip()