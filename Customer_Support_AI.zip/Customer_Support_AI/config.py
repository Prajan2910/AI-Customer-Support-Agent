import os

# ===========================
# OLLAMA
# ===========================

OLLAMA_BASE_URL = "http://localhost:11434"

LLM_MODEL = "qwen2.5:3b"

EMBED_MODEL = "nomic-embed-text"

# Backward compatibility
OLLAMA_MODEL = LLM_MODEL

# ===========================
# PATHS
# ===========================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DATA_DIR = os.path.join(BASE_DIR, "data")

FAISS_DIR = os.path.join(BASE_DIR, "faiss_index")

MEMORY_DB = os.path.join(BASE_DIR, "memory", "memory.db")

# ===========================
# RAG
# ===========================

CHUNK_SIZE = 500

CHUNK_OVERLAP = 50

TOP_K = 4

# ===========================
# Human Approval
# ===========================

HITL_KEYWORDS = [

    "refund",

    "cancel",

    "cancellation",

    "close account",

    "account closure",

    "compensation",

    "management",

    "escalate",

]

# ===========================
# Debug
# ===========================

DEBUG = False