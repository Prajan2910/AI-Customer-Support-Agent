# AI Powered Customer Support Automation System

Built using

- LangGraph
- Ollama (Qwen2.5:3B)
- FAISS
- SQLite Memory
- Rich Terminal UI

---

## Features

✔ Intent Classification

✔ Department Routing

✔ Sales Agent

✔ Technical Support Agent

✔ Billing Agent

✔ Account Agent

✔ Retrieval-Augmented Generation (RAG)

✔ SQLite Conversation Memory

✔ Human-in-the-loop Approval

✔ Supervisor Agent

✔ Final Customer Response

---

## Project Structure

```
Customer_Support_AI
│
├── agents
├── data
├── graph
├── memory
├── rag
├── app.py
├── config.py
└── requirements.txt
```

---

## Installation

Create Virtual Environment

```
python -m venv .venv
```

Windows

```
.venv\Scripts\activate
```

Upgrade pip

```
python -m pip install --upgrade pip
```

Install dependencies

```
pip install -r requirements.txt
```

---

## Install Ollama Models

```
ollama pull qwen2.5:3b
```

```
ollama pull nomic-embed-text
```

Start Ollama

```
ollama serve
```

---

## Run

```
python app.py
```

---

## Sample Queries

What are the pricing plans available?

I forgot my password.

My application crashes while uploading files.

I need a refund for my annual subscription.

What was my previous issue?

---

## Assignment Coverage

Task 1 ✅ Workflow

Task 2 ✅ State

Task 3 ✅ Intent Classification

Task 4 ✅ Conditional Routing

Task 5 ✅ Department Agents

Task 6 ✅ RAG

Task 7 ✅ SQLite Memory

Task 8 ✅ Human Approval

Task 9 ✅ Supervisor

Task 10 ✅ Demonstration